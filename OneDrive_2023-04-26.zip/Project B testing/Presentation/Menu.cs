static class Menu
{

    //This shows the menu. You can call back to this method to show the menu again
    //after another presentation method is completed.
    //You could edit this to show different menus depending on the user's role
    static public void Start(bool user)
    {


        bool Admin = false;
        // ConsoleKeyInfo cki;
        // cki = Console.ReadKey();
        // Console.WriteLine("u pressed ");
        // Random rnd = new Random();
        // int menu = rnd.Next(1, 3);


        string menu2 = @"
______ _                                  ______      _   _               _                 
| ___ (_)                                 | ___ \    | | | |             | |                
| |_/ /_  ___  ___  ___ ___   ___  _ __   | |_/ /___ | |_| |_ ___ _ __ __| | __ _ _ __ ___  
| ___ | |/ _ \/ __|/ __/ _ \ / _ \| '_ \  |    // _ \| __| __/ _ | '__/ _` |/ _` | '_ ` _ \ 
| |_/ | | (_) \__ | (_| (_) | (_) | |_) | | |\ | (_) | |_| ||  __| | | (_| | (_| | | | | | |
\____/|_|\___/|___/\___\___/ \___/| .__/  \_| \_\___/ \__|\__\___|_|  \__,_|\__,_|_| |_| |_|
                                  | |                                                       
                                  |_|";

        Console.WriteLine(menu2);

        if (Admin == true)
        {
            Console.WriteLine("[A]- Films met beheerderstoegang");
        }
        if (user != true && Admin != true)
        {
            Console.WriteLine("[L1]- Inloggen");
        }
        Console.WriteLine("[B]- Informatie Bioscoop");
        Console.WriteLine("[M]- Overzicht films");
        Console.WriteLine("[R]- Reserveren");
        if (user == true || Admin == true)
        {
            Console.WriteLine("[L2]- Uitloggen");
        }
        Console.WriteLine("[Q]- Programma afsluiten");

        string input = Console.ReadLine().ToUpper();
        if (input == "L1")
        {
            Console.Clear();
            UserLogin.Start();

        }
        else if (input == "B")
        {
            Console.Clear();
            Console.WriteLine("U wordt doorgestuurd naar onze bioscoopinformatiepagina...");
            Info.CinemaInfo(user);
        }
        else if (input == "M")
        {
            Console.Clear();
            Console.WriteLine("U wordt doorgestuurd naar onze filmbibliotheek...");
            Overzicht_Customer.User(user);


            // Overzicht();
        }
        else if (input == "R")
        {
            Console.Clear();
            Console.WriteLine("Uw reservering begint hier");
            Reservering.Reserveren(user);

            // Reservation();
        }
        else if (input == "L2" && user == true || input == "L2" && Admin == true)
        {
            Console.WriteLine("Weet u zeker dat u wilt uitloggen? (Y or N)");
            string choice = Console.ReadLine().ToUpper();
            if (choice == "Y")
            {
                Console.Clear();
                Console.WriteLine("U wordt uitgelogd...");
                user = false;

                Start(user);
            }
            else if (choice == "N")
            {
                Console.WriteLine("Terug naar de menukaart");
                Start(user);
            }
            else
            {
                Console.WriteLine("Ongeldige invoer");
                Start(user);
            }
        }
        else if (input == "Q")
        {
            Console.WriteLine("Wilt u de applicatie verlaten? [Y] or [N]");
            string choice = Console.ReadLine().ToUpper();
            if (choice == "Y")
            {
                Console.WriteLine("Programma afsluiten...");


            }
            else if (choice == "N")
            {
                Console.Clear();
                Console.WriteLine("Terug naar de menukaart");

                Start(user);
            }
            else
            {
                Console.Clear();
                Console.WriteLine("Ongeldige invoer");

                Start(user);

            }
        }
        else if (input == "A" && Admin == true)
        {

            Console.WriteLine("Hallo beheerder. U kunt films toevoegen of verwijderen en de gegevens van de films wijzigen, wat ook mogelijk is.");
            // AdminOverzicht();

        }
        else
        {
            Console.WriteLine("Ongeldige invoer");
            Console.Clear();
            Start(user);
        }

    }
}