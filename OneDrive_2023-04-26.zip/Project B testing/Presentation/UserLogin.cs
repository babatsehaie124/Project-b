static class UserLogin
{
    static private AccountsLogic accountsLogic = new AccountsLogic();


    public static void Start()
    {
        Console.WriteLine("Welkom bij de inlogpagina");
        Console.WriteLine("Vul alstublieft uw e-mail adres in:");
        string email = Console.ReadLine();
        Console.WriteLine("Voer uw wachtwoord in:");
        string password = Console.ReadLine();
        AccountModel acc = accountsLogic.CheckLogin(email, password);
        if (acc != null)
        {
            Console.Clear();
            Console.WriteLine("Welkom terug " + acc.FullName);
            Console.WriteLine("Uw e-mailadres is " + acc.EmailAddress);

            //Write some code to go back to the menu
            bool user = true;
            Menu.Start(user);
        }
        else
        {
            Console.Clear();
            Console.WriteLine("Geen account gevonden met dat e-mailadres en/of wachtwoord");
            bool user = false;
            Menu.Start(user);

        }
    }
}