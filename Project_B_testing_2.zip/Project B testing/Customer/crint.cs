public class Movies
{
    public string Title { get; set; }
    public string Genres { get; set; }
    public string Director { get; set; }
    public string LeadActor { get; set; }
    public int Duration { get; set; }
    public string Release { get; set; }
    public string Description { get; set; }
    public string Price { get; set; }
}