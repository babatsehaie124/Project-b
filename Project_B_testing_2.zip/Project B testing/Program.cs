﻿// See https://aka.ms/new-console-template for more information

Console.Clear();
bool user = false;
Menu.Start(user);
